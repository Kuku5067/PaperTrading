"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { BarChart3, Search, LineChart, PieChart, Wallet, History, Settings, LogOut, Menu, X, Bell } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"

export function DashboardLayout({ children }: { children: React.ReactNode }) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [mounted, setMounted] = useState(false)

  // Prevent hydration mismatch
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="flex min-h-screen bg-background">
      {/* Mobile sidebar toggle */}
      <Button
        variant="ghost"
        size="icon"
        className="fixed top-4 left-4 z-50 md:hidden hover:bg-muted/50"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
      >
        {isSidebarOpen ? <X className="text-primary" /> : <Menu className="text-primary" />}
      </Button>

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-40 w-64 transform navy-card transition-transform duration-300 ease-in-out md:translate-x-0 ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="p-6">
            <div className="flex items-center gap-3 mb-8">
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center professional-shadow">
                <span className="text-white font-bold elegant-text">TP</span>
              </div>
              <h1 className="text-xl font-bold elegant-heading">TradePaper</h1>
            </div>

            <div className="relative mb-6">
              <Search className="absolute left-3 top-3 h-4 w-4 text-primary" />
              <Input
                type="search"
                placeholder="Search stocks..."
                className="pl-10 bg-muted/30 border-border/50 focus:border-primary smooth-transition"
              />
            </div>

            <nav className="space-y-2">
              <Link
                href="#"
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-primary transition-all hover:bg-muted/30 glow-aqua smooth-transition"
              >
                <BarChart3 className="h-5 w-5" />
                <span className="elegant-text">Dashboard</span>
              </Link>
              <Link
                href="#"
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-muted-foreground transition-all hover:bg-muted/30 hover:text-primary smooth-transition"
              >
                <LineChart className="h-5 w-5" />
                <span className="elegant-text">Markets</span>
              </Link>
              <Link
                href="#"
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-muted-foreground transition-all hover:bg-muted/30 hover:text-primary smooth-transition"
              >
                <PieChart className="h-5 w-5" />
                <span className="elegant-text">Portfolio</span>
                <Badge className="ml-auto bg-primary/20 text-primary hover:bg-primary/30 border-primary/30">
                  +2.4%
                </Badge>
              </Link>
              <Link
                href="#"
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-muted-foreground transition-all hover:bg-muted/30 hover:text-primary smooth-transition"
              >
                <Wallet className="h-5 w-5" />
                <span className="elegant-text">Orders</span>
              </Link>
              <Link
                href="#"
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-muted-foreground transition-all hover:bg-muted/30 hover:text-primary smooth-transition"
              >
                <History className="h-5 w-5" />
                <span className="elegant-text">History</span>
              </Link>
            </nav>
          </div>

          <div className="mt-auto p-6 border-t border-border/30">
            <div className="flex items-center gap-3 mb-6">
              <Avatar className="border-2 border-primary/30 professional-shadow">
                <AvatarImage src="/placeholder.svg" />
                <AvatarFallback className="bg-muted text-primary elegant-text">JD</AvatarFallback>
              </Avatar>
              <div>
                <p className="text-sm font-medium elegant-text">John Doe</p>
                <p className="text-xs text-primary glow-aqua">$25,420.65</p>
              </div>
            </div>

            <div className="space-y-2">
              <Link
                href="#"
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-muted-foreground transition-all hover:bg-muted/30 hover:text-primary smooth-transition"
              >
                <Settings className="h-5 w-5" />
                <span className="elegant-text">Settings</span>
              </Link>
              <Link
                href="#"
                className="flex items-center gap-3 rounded-lg px-4 py-3 text-muted-foreground transition-all hover:bg-muted/30 hover:text-primary smooth-transition"
              >
                <LogOut className="h-5 w-5" />
                <span className="elegant-text">Log out</span>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 md:ml-64">
        {/* Header */}
        <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b border-border/30 bg-background/80 px-4 backdrop-blur-lg sm:px-6 lg:px-8">
          <div className="ml-auto flex items-center gap-4">
            <Button
              variant="outline"
              size="icon"
              className="relative border-border/30 hover:border-primary/50 hover:bg-muted/30 smooth-transition professional-shadow-hover"
            >
              <Bell className="h-5 w-5 text-primary" />
              <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-coral pulse"></span>
            </Button>
            <Avatar className="h-8 w-8 md:hidden border border-primary/30 professional-shadow">
              <AvatarImage src="/placeholder.svg" />
              <AvatarFallback className="bg-muted text-primary elegant-text">JD</AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  )
}
