"use client"

import { useState } from "react"
import { ArrowUp, Clock, DollarSign, LineChart, Search, TrendingUp } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { StockChart } from "@/components/stock-chart"
import { OrderForm } from "@/components/order-form"
import { PortfolioOverview } from "@/components/portfolio-overview"
import { RecentTransactions } from "@/components/recent-transactions"

export function DashboardContent() {
  const [searchQuery, setSearchQuery] = useState("")

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight elegant-heading">Dashboard</h1>
          <p className="text-muted-foreground elegant-text">Welcome back! Your portfolio is up 2.4% today.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-primary" />
            <Input
              type="search"
              placeholder="Search stocks..."
              className="pl-10 w-[200px] md:w-[300px] bg-muted/30 border-border/50 focus:border-primary smooth-transition"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button className="professional-button elegant-text">
            <DollarSign className="mr-2 h-4 w-4" />
            Deposit
          </Button>
        </div>
      </div>

      {/* Portfolio Summary Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="navy-card professional-shadow-hover smooth-transition">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm font-medium elegant-text">Portfolio Value</CardTitle>
            <DollarSign className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold glow-aqua elegant-text">$25,420.65</div>
            <div className="flex items-center text-xs text-positive mt-2">
              <TrendingUp className="mr-1 h-4 w-4" />
              +2.4% from yesterday
            </div>
          </CardContent>
        </Card>
        <Card className="navy-card professional-shadow-hover smooth-transition">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm font-medium elegant-text">Day's Gain/Loss</CardTitle>
            <LineChart className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold price-up elegant-text">+$598.32</div>
            <div className="flex items-center text-xs text-positive mt-2">
              <ArrowUp className="mr-1 h-4 w-4" />
              +2.4% today
            </div>
          </CardContent>
        </Card>
        <Card className="navy-card professional-shadow-hover smooth-transition">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm font-medium elegant-text">Total Gain/Loss</CardTitle>
            <TrendingUp className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold price-up elegant-text">+$5,420.65</div>
            <div className="flex items-center text-xs text-positive mt-2">
              <ArrowUp className="mr-1 h-4 w-4" />
              +27.1% all time
            </div>
          </CardContent>
        </Card>
        <Card className="navy-card professional-shadow-hover smooth-transition">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm font-medium elegant-text">Available Cash</CardTitle>
            <DollarSign className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold glow-aqua elegant-text">$12,580.00</div>
            <div className="flex items-center text-xs text-muted-foreground mt-2">
              <Clock className="mr-1 h-4 w-4" />
              Last deposit 2d ago
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid gap-8 md:grid-cols-7">
        {/* Chart and Order Form */}
        <div className="md:col-span-5 space-y-8">
          <Card className="navy-card professional-shadow-hover smooth-transition">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="flex items-center elegant-text">
                  <span className="glow-aqua">AAPL</span>
                  <span className="mx-3 text-muted-foreground">-</span>
                  <span>Apple Inc.</span>
                </CardTitle>
                <CardDescription className="flex items-center mt-2">
                  <span className="text-3xl font-bold mr-3 glow-aqua elegant-text">$182.63</span>
                  <span className="flex items-center text-positive">
                    <ArrowUp className="mr-1 h-4 w-4" />
                    2.45 (1.36%)
                  </span>
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-border/30 hover:border-primary/50 hover:bg-muted/30 smooth-transition"
                >
                  1D
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-border/30 hover:border-primary/50 hover:bg-muted/30 smooth-transition"
                >
                  1W
                </Button>
                <Button variant="outline" size="sm" className="bg-muted/50 border-primary/30 text-primary glow-aqua">
                  1M
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-border/30 hover:border-primary/50 hover:bg-muted/30 smooth-transition"
                >
                  1Y
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-border/30 hover:border-primary/50 hover:bg-muted/30 smooth-transition"
                >
                  All
                </Button>
              </div>
            </CardHeader>
            <CardContent className="pt-6">
              <StockChart />
            </CardContent>
          </Card>

          <Tabs defaultValue="portfolio" className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-muted/30 p-1 border border-border/30">
              <TabsTrigger
                value="portfolio"
                className="data-[state=active]:bg-background data-[state=active]:text-primary data-[state=active]:shadow-none data-[state=active]:glow-aqua elegant-text"
              >
                Portfolio Overview
              </TabsTrigger>
              <TabsTrigger
                value="transactions"
                className="data-[state=active]:bg-background data-[state=active]:text-primary data-[state=active]:shadow-none data-[state=active]:glow-aqua elegant-text"
              >
                Recent Transactions
              </TabsTrigger>
            </TabsList>
            <TabsContent value="portfolio" className="mt-6">
              <Card className="navy-card professional-shadow-hover smooth-transition">
                <CardHeader>
                  <CardTitle className="elegant-heading">Your Portfolio</CardTitle>
                  <CardDescription className="elegant-text">Overview of your current stock holdings</CardDescription>
                </CardHeader>
                <CardContent>
                  <PortfolioOverview />
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="transactions" className="mt-6">
              <Card className="navy-card professional-shadow-hover smooth-transition">
                <CardHeader>
                  <CardTitle className="elegant-heading">Recent Transactions</CardTitle>
                  <CardDescription className="elegant-text">Your recent trading activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <RecentTransactions />
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>

        {/* Order Form */}
        <div className="md:col-span-2">
          <Card className="navy-card professional-shadow-hover smooth-transition sticky top-20">
            <CardHeader>
              <CardTitle className="elegant-heading">Place Order</CardTitle>
              <CardDescription className="elegant-text">Buy or sell AAPL stock</CardDescription>
            </CardHeader>
            <CardContent>
              <OrderForm />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
