"use client"

import { Clock } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"

const transactionsData = [
  {
    id: "TX123456",
    date: "2023-06-10T14:30:00",
    symbol: "AAPL",
    type: "buy",
    shares: 10,
    price: 182.63,
    total: 1826.3,
  },
  {
    id: "TX123455",
    date: "2023-06-09T10:15:00",
    symbol: "MSFT",
    type: "buy",
    shares: 5,
    price: 315.75,
    total: 1578.75,
  },
  {
    id: "TX123454",
    date: "2023-06-08T15:45:00",
    symbol: "TSLA",
    type: "sell",
    shares: 3,
    price: 750.25,
    total: 2250.75,
  },
  {
    id: "TX123453",
    date: "2023-06-07T09:30:00",
    symbol: "GOOGL",
    type: "buy",
    shares: 2,
    price: 2050.8,
    total: 4101.6,
  },
  {
    id: "TX123452",
    date: "2023-06-05T11:20:00",
    symbol: "AMZN",
    type: "sell",
    shares: 1,
    price: 3250.0,
    total: 3250.0,
  },
  {
    id: "TX123451",
    date: "2023-06-02T16:05:00",
    symbol: "AAPL",
    type: "buy",
    shares: 15,
    price: 180.5,
    total: 2707.5,
  },
]

export function RecentTransactions() {
  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="border-border/30 hover:bg-muted/10">
            <TableHead className="elegant-text">Date</TableHead>
            <TableHead className="elegant-text">Symbol</TableHead>
            <TableHead className="elegant-text">Type</TableHead>
            <TableHead className="text-right elegant-text">Shares</TableHead>
            <TableHead className="text-right elegant-text">Price</TableHead>
            <TableHead className="text-right elegant-text">Total</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactionsData.map((transaction) => (
            <TableRow key={transaction.id} className="border-border/30 hover:bg-muted/10 smooth-transition">
              <TableCell>
                <div className="flex items-center">
                  <Clock className="mr-2 h-4 w-4 text-primary" />
                  <span className="elegant-text">{formatDate(transaction.date)}</span>
                </div>
              </TableCell>
              <TableCell className="font-medium glow-aqua elegant-text">{transaction.symbol}</TableCell>
              <TableCell>
                <Badge
                  variant="outline"
                  className={
                    transaction.type === "buy"
                      ? "border-primary/30 text-primary bg-primary/10 elegant-text"
                      : "border-coral/30 text-coral bg-coral/10 elegant-text"
                  }
                >
                  {transaction.type === "buy" ? "Buy" : "Sell"}
                </Badge>
              </TableCell>
              <TableCell className="text-right elegant-text">{transaction.shares}</TableCell>
              <TableCell className="text-right elegant-text">${transaction.price.toFixed(2)}</TableCell>
              <TableCell className="text-right font-medium elegant-text">${transaction.total.toFixed(2)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
