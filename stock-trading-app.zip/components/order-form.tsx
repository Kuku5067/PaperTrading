"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"

export function OrderForm() {
  const [orderType, setOrderType] = useState("market")
  const [quantity, setQuantity] = useState("1")
  const [price, setPrice] = useState("182.63")
  const [total, setTotal] = useState("182.63")

  const handleQuantityChange = (e) => {
    const value = e.target.value
    if (value === "" || /^\d*\.?\d*$/.test(value)) {
      setQuantity(value)
      const numValue = Number.parseFloat(value) || 0
      setTotal((numValue * Number.parseFloat(price)).toFixed(2))
    }
  }

  const handleSliderChange = (value) => {
    const newQuantity = value[0].toString()
    setQuantity(newQuantity)
    setTotal((Number.parseFloat(newQuantity) * Number.parseFloat(price)).toFixed(2))
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="buy" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-muted/30 p-1 border border-border/30">
          <TabsTrigger
            value="buy"
            className="data-[state=active]:bg-background data-[state=active]:text-primary data-[state=active]:shadow-none data-[state=active]:glow-aqua elegant-text"
          >
            Buy
          </TabsTrigger>
          <TabsTrigger
            value="sell"
            className="data-[state=active]:bg-background data-[state=active]:text-primary data-[state=active]:shadow-none data-[state=active]:glow-aqua elegant-text"
          >
            Sell
          </TabsTrigger>
        </TabsList>
        <TabsContent value="buy" className="space-y-6 pt-6">
          <div className="space-y-3">
            <Label htmlFor="order-type" className="elegant-text">
              Order Type
            </Label>
            <Select defaultValue="market" onValueChange={setOrderType}>
              <SelectTrigger
                id="order-type"
                className="bg-muted/30 border-border/50 focus:border-primary smooth-transition"
              >
                <SelectValue placeholder="Select order type" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border/30">
                <SelectItem value="market">Market Order</SelectItem>
                <SelectItem value="limit">Limit Order</SelectItem>
                <SelectItem value="stop">Stop Order</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            <Label htmlFor="quantity" className="elegant-text">
              Quantity
            </Label>
            <Input
              id="quantity"
              type="text"
              value={quantity}
              onChange={handleQuantityChange}
              className="bg-muted/30 border-border/50 focus:border-primary smooth-transition"
            />
            <Slider
              defaultValue={[1]}
              max={10}
              step={1}
              value={[Number.parseFloat(quantity) || 0]}
              onValueChange={handleSliderChange}
              className="py-4"
            />
          </div>

          {orderType !== "market" && (
            <div className="space-y-3">
              <Label htmlFor="price" className="elegant-text">
                Price ($)
              </Label>
              <Input
                id="price"
                type="text"
                value={price}
                onChange={(e) => {
                  const value = e.target.value
                  if (value === "" || /^\d*\.?\d*$/.test(value)) {
                    setPrice(value)
                    setTotal((Number.parseFloat(quantity) * (Number.parseFloat(value) || 0)).toFixed(2))
                  }
                }}
                className="bg-muted/30 border-border/50 focus:border-primary smooth-transition"
              />
            </div>
          )}

          <div className="pt-4">
            <div className="flex items-center justify-between text-sm pb-3">
              <span className="text-muted-foreground elegant-text">Estimated Cost</span>
              <span className="font-medium glow-aqua elegant-text">${total}</span>
            </div>
            <div className="flex items-center justify-between text-sm pb-3">
              <span className="text-muted-foreground elegant-text">Available Cash</span>
              <span className="font-medium elegant-text">$12,580.00</span>
            </div>
            <div className="border-t border-border/30 my-4"></div>
            <div className="gradient-border">
              <Button className="w-full professional-button elegant-text">Buy AAPL</Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="sell" className="space-y-6 pt-6">
          <div className="space-y-3">
            <Label htmlFor="sell-order-type" className="elegant-text">
              Order Type
            </Label>
            <Select defaultValue="market">
              <SelectTrigger
                id="sell-order-type"
                className="bg-muted/30 border-border/50 focus:border-primary smooth-transition"
              >
                <SelectValue placeholder="Select order type" />
              </SelectTrigger>
              <SelectContent className="bg-card border-border/30">
                <SelectItem value="market">Market Order</SelectItem>
                <SelectItem value="limit">Limit Order</SelectItem>
                <SelectItem value="stop">Stop Order</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            <Label htmlFor="sell-quantity" className="elegant-text">
              Quantity
            </Label>
            <Input
              id="sell-quantity"
              type="text"
              defaultValue="10"
              className="bg-muted/30 border-border/50 focus:border-primary smooth-transition"
            />
            <Slider defaultValue={[10]} max={50} step={1} className="py-4" />
          </div>

          <div className="pt-4">
            <div className="flex items-center justify-between text-sm pb-3">
              <span className="text-muted-foreground elegant-text">Estimated Value</span>
              <span className="font-medium glow-aqua elegant-text">$1,826.30</span>
            </div>
            <div className="flex items-center justify-between text-sm pb-3">
              <span className="text-muted-foreground elegant-text">Current Position</span>
              <span className="font-medium elegant-text">50 shares</span>
            </div>
            <div className="border-t border-border/30 my-4"></div>
            <div className="gradient-border">
              <Button className="w-full professional-button elegant-text bg-gradient-to-r from-coral to-destructive hover:from-coral/90 hover:to-destructive/90">
                Sell AAPL
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
