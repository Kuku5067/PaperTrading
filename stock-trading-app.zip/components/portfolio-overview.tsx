"use client"

import { ArrowDown, ArrowUp, MoreHorizontal } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const portfolioData = [
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    shares: 50,
    avgPrice: 150.25,
    currentPrice: 182.63,
    value: 9131.5,
    change: 32.38,
    changePercent: 21.55,
  },
  {
    symbol: "MSFT",
    name: "Microsoft Corp.",
    shares: 25,
    avgPrice: 280.1,
    currentPrice: 315.75,
    value: 7893.75,
    change: 35.65,
    changePercent: 12.73,
  },
  {
    symbol: "GOOGL",
    name: "Alphabet Inc.",
    shares: 10,
    avgPrice: 2100.5,
    currentPrice: 2050.8,
    value: 20508.0,
    change: -49.7,
    changePercent: -2.37,
  },
  {
    symbol: "AMZN",
    name: "Amazon.com Inc.",
    shares: 15,
    avgPrice: 3100.25,
    currentPrice: 3250.0,
    value: 48750.0,
    change: 149.75,
    changePercent: 4.83,
  },
  {
    symbol: "TSLA",
    name: "Tesla Inc.",
    shares: 20,
    avgPrice: 800.5,
    currentPrice: 750.25,
    value: 15005.0,
    change: -50.25,
    changePercent: -6.28,
  },
]

export function PortfolioOverview() {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="border-border/30 hover:bg-muted/10">
            <TableHead className="elegant-text">Symbol</TableHead>
            <TableHead className="hidden md:table-cell elegant-text">Name</TableHead>
            <TableHead className="elegant-text">Shares</TableHead>
            <TableHead className="hidden md:table-cell elegant-text">Avg Price</TableHead>
            <TableHead className="elegant-text">Current</TableHead>
            <TableHead className="text-right elegant-text">Value</TableHead>
            <TableHead className="text-right elegant-text">Change</TableHead>
            <TableHead></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {portfolioData.map((stock) => (
            <TableRow key={stock.symbol} className="border-border/30 hover:bg-muted/10 smooth-transition">
              <TableCell className="font-medium glow-aqua elegant-text">{stock.symbol}</TableCell>
              <TableCell className="hidden md:table-cell elegant-text">{stock.name}</TableCell>
              <TableCell className="elegant-text">{stock.shares}</TableCell>
              <TableCell className="hidden md:table-cell elegant-text">${stock.avgPrice.toFixed(2)}</TableCell>
              <TableCell className="elegant-text">${stock.currentPrice.toFixed(2)}</TableCell>
              <TableCell className="text-right font-medium elegant-text">${stock.value.toFixed(2)}</TableCell>
              <TableCell className={`text-right ${stock.change >= 0 ? "text-positive" : "text-negative"}`}>
                <div className="flex items-center justify-end">
                  {stock.change >= 0 ? <ArrowUp className="mr-1 h-4 w-4" /> : <ArrowDown className="mr-1 h-4 w-4" />}
                  <span className="elegant-text">{Math.abs(stock.changePercent).toFixed(2)}%</span>
                </div>
              </TableCell>
              <TableCell>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="hover:bg-muted/30 hover:text-primary smooth-transition"
                    >
                      <MoreHorizontal className="h-4 w-4" />
                      <span className="sr-only">Actions</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-card border-border/30">
                    <DropdownMenuItem className="hover:bg-muted/30 hover:text-primary cursor-pointer elegant-text">
                      Buy More
                    </DropdownMenuItem>
                    <DropdownMenuItem className="hover:bg-muted/30 hover:text-primary cursor-pointer elegant-text">
                      Sell Position
                    </DropdownMenuItem>
                    <DropdownMenuItem className="hover:bg-muted/30 hover:text-primary cursor-pointer elegant-text">
                      View Details
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
